package net.hb.crud;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate; //dao-context.xml���� �Ǹ������� bean����ȭ
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;

@Repository
@Component
public class CustomerDAO {

	@Autowired
	SqlSessionTemplate temp;
	
	// ȸ�� ���� ���========================================================
	public BoardDTO infoSelect(BoardDTO dto) {
		return temp.selectOne("customer.infoSelect", dto);
	}//end
	
	// �ۼ��� ����Ʈ ���========================================================
	public List<BoardDTO> mypage_BoardSelect(BoardDTO dto) {
		return temp.selectList("customer.boardSelect", dto);
	}//end
	
	
	// ��� ����Ʈ ���========================================================
	public List<BoardDTO> replyList(String custid) {
		return temp.selectList("customer.replyListSelect", custid);
	}//end
	
	// ���� ����Ʈ ���========================================================
	public List<BoardDTO> questionList(String custid) {
		return temp.selectList("customer.questionListSelect", custid);
	}//end
	
	// ���� ����Ʈ ���========================================================
	public List<BoardDTO> answerList(String custid) {
		return temp.selectList("customer.answerListSelect", custid);
	}//end
	
	// ��õ�� �� ����Ʈ ���========================================================
	public List<BoardDTO> heartList(String custid) {
		return temp.selectList("customer.heartListSelect", custid);
	}//end
	
	//�ۼ��� ���� cnt ���  ========================================================
	public int boardListCount(String custid) {
		return temp.selectOne("customer.boardListCount", custid);
	}
	
	//��� ���� cnt ��� ========================================================
	public int replyListCount(String custid) {
		return temp.selectOne("customer.replyListCount", custid);
	}
	
	//�Խñ� ���� cnt ���  ========================================================
	public int BoardListCount(String custid) {
		return temp.selectOne("customer.boardListCount", custid);
	}
	
	//���� ���� cnt ���  ========================================================
	public int questionListCount(String custid) {
		return temp.selectOne("customer.questionListCount", custid);
	}

	//�亯 ���� cnt ���  ========================================================
	public int answerListCount(String custid) {
		return temp.selectOne("customer.answerListCount", custid);
	}
	
	//��õ ���� cnt ���  ========================================================
	public int heartListCount(String custid) {
		return temp.selectOne("customer.heartListCount", custid);
	}
	
	
	
}//CustomerDAO class END



