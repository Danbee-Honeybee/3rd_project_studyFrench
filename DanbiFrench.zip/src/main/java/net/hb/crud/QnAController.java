package net.hb.crud;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.inject.Inject;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import java.io.File;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.FileInputStream;

import java.net.URLEncoder;


@Controller
public class QnAController {
	
	private static final Logger logger = LoggerFactory.getLogger(QnAController.class);

	@Inject
	@Autowired
	ServletContext application;
	
	@Inject
	@Autowired
	QnADAO dao;

	
	 
	/*���� �Խ��� ����Ʈ ========================================================*/
	@RequestMapping("/qna_community.do")
	public String qna_community(Model model) {
		List<QnADTO> qdto = dao.questionSelect();
		model.addAttribute("qdto", qdto);
		return "qna_community";
	}//end
	
	/*���� ���� ���� �̵� ========================================================*/
	@RequestMapping("/question.do")
	public String question() {
		return "qna_write";
	}//end
	
	/*���� �Ѱ� ���� ========================================================*/
	@RequestMapping("/questionSave.do")
	public String questionSave(HttpSession session, QnADTO dto) {
		String custid = (String) session.getAttribute("custid");
		dto.setCustid(custid);
		
		dao.questionInsert(dto);
		return "redirect:/qna_community.do";
	}//end
	
	
	/*���� �Ѱ� �� ========================================================*/
	@RequestMapping("/qnaDetail.do")
	public String qnaDetail(@RequestParam int idx, Model model) {
		QnADTO qdto = dao.qnaDetail(idx);
		dao.answerCount(idx);
		model.addAttribute("qdto", qdto);
		return "qna_detail";
	}//end	
		
	/*���� ���� �����̵�==================================================================*/
	@RequestMapping("/qedit.do")
	public String qedit(@RequestParam int idx, Model model) {
		
		System.out.println("========================================");
		System.out.println("���� �̵��� ���� ���� idx : "+idx);
		System.out.println("========================================");
		
		QnADTO dto = dao.qnaDetail(idx);
		model.addAttribute("idx", idx);
		model.addAttribute("qdto", dto);
		return "qna_edit";
	}//end	
	
	
	/*���� ���� ����==================================================================*/
	@RequestMapping("/qeditSave.do")
	public String qeditSave(QnADTO dto, @RequestParam("idx") int idx, Model model) {
		dto.setQna_idx(idx);
		dao.questionEdit(dto);
		dto=dao.qnaDetail(idx);
		model.addAttribute("qdto", dto);
		return "qna_detail";
	}//end
	
	
	/*���� �Ѱ� ����==================================================================*/
	@RequestMapping("/qdelete.do")
	public String qdelete(@RequestParam("idx") int idx, Model model) {
		dao.qustionDelete(idx);
		return "redirect:/qna_community.do";
	}//end
	
	/*�亯 ����Ʈ ��� ========================================================*/
	@RequestMapping("/answerSelect.do")
	public ModelAndView answerSelect(@RequestParam("idx") int qna_idx) {
		ModelAndView mav = new ModelAndView();
		List<QnADTO> adto = dao.answerSelect(qna_idx);
		mav.addObject("adto",adto);
		mav.addObject("qna_idx", qna_idx);
		mav.setViewName("qna_reply");
		return mav;
	}
	
	/*�亯 ��� ========================================================*/
	@RequestMapping(value="/answerInsert.do",method=RequestMethod.POST)
	public String answer_Insert(QnADTO dto, Model model, HttpSession session) {
		String awriter = (String) session.getAttribute("custid");
		dto.setAwriter(awriter);
		dao.answerInsert(dto); /*�亯���� DAO*/
		return "redirect:/qnaDetail.do?idx="+dto.getQna_idx();
		
	}//end
	
	/*�亯 �Ѱ� ��*/
	@RequestMapping("/answerSelectOne.do")
	public ModelAndView answerSelectOne(@RequestParam("idx") int idx) {
		ModelAndView mav = new ModelAndView();
		int answer_idx = idx;
		
		QnADTO adto = dao.answerSelectOne(idx); //�亯 �Ѱ� ��
		
		System.out.println("==============================");
		System.out.println("answer_idx : "+adto.getAnswer_idx());
		System.out.println("awriter : "+adto.getAwriter());
		System.out.println("acontent : "+adto.getAcontent());
		System.out.println("qna_idx : "+adto.getQna_idx());
		System.out.println("==============================");
		
		mav.addObject("adto",adto);
		mav.setViewName("qna_reply");
		return mav;
	}
	
	/*�亯 ���� ����====================================================================*/
	@RequestMapping("/answerEdit.do")
	public String answer_Edit(@RequestParam("idx") int idx, @RequestParam("qna_idx") int qna_idx, @RequestParam("acontent") String acontent, QnADTO dto, HttpSession session) {
		String awriter = (String) session.getAttribute("custid");
		dto.setAwriter(awriter);
		dto.setAnswer_idx(idx);
		dto.setAcontent(acontent);
		
		dao.answerEdit(dto); /*�亯 ���� DAO*/
		return "redirect:/qnaDetail.do?idx="+qna_idx;
	}//end
	
	/*�亯 �Ѱ� ���� answerDelete.do*/
	@RequestMapping("/answerDelete.do")
	public String detail_delete(@RequestParam("idx") int idx, @RequestParam("answer_idx") int answer_idx, Model model) {
		dao.answerDelete(answer_idx);
		return "redirect:/qnaDetail.do?idx="+idx;
	}//end
	
	
}//class END







