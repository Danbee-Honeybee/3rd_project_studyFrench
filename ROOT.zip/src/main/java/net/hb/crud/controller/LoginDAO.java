package net.hb.crud.controller;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

@Repository
@Component
public class LoginDAO {
	
	@Autowired
	SqlSessionTemplate temp;
	
	
	/*���̵� �ߺ�üũ*/
	public int idcheckSave(String custid) {
		LoginDTO dto = new LoginDTO();
		dto.setCustid(custid);
		int cnt = temp.selectOne("login.idcheck", dto);//custid�� �ִٸ� 1
		return cnt; 
	}
}
