package net.hb.crud.controller;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate; //dao-context.xml���� �Ǹ������� bean����ȭ
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;

@Repository
@Component
public class CustomerDAO {

	@Autowired
	SqlSessionTemplate temp;
	
}//CustomerDAO class END



